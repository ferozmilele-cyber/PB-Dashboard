PB Downloader
=============

Turn it on (once)
1. Unzip this folder somewhere it can stay, for example Documents. Dont delete or move it afterwards.
2. Double-click "Start Downloader".
   If Windows says "Windows protected your PC", click More info, then Run anyway.
3. The first time, it downloads the tools it needs (yt-dlp, ffmpeg and Deno, about 200 MB). This takes a few minutes, only once.
4. The window closes by itself. PB Downloader now runs in the background and starts by itself whenever Windows starts.

Use it from the Downloader tab in the PB Dashboard, or open http://localhost:8765 in your browser.
Videos are saved to Downloads > PB Downloads.

Turn it off
Double-click "Turn off Downloader". It stops and wont start with Windows any more. Double-click "Start Downloader" to turn it back on.

Instagram asks you to log in?
In the Downloader tab, set "Signed in with" to the browser where you are signed in to Instagram. Firefox works best. For Edge or Chrome, close that browser fully first.
