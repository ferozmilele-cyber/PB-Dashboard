# PB Downloader: a small local server that downloads Instagram, TikTok and YouTube links with yt-dlp.
# It only listens on this computer (localhost).
#   -Install     first-time setup: gets the tools, starts it hidden and makes it start with Windows
#   -Background  the hidden server itself (what runs at sign-in)
#   -Uninstall   stops it and removes it from start-up
param([switch]$Background, [switch]$Install, [switch]$Uninstall)
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 } catch {}
try { [Console]::OutputEncoding = [Text.Encoding]::UTF8 } catch {}
Add-Type -AssemblyName System.IO.Compression.FileSystem

$App   = Split-Path -Parent $MyInvocation.MyCommand.Path
$Bin   = Join-Path $App 'bin'
$Jobs  = Join-Path $App 'jobs'
$IsWin = ($env:OS -eq 'Windows_NT')
$Exe   = ''; if ($IsWin) { $Exe = '.exe' }
$YtDlp = Join-Path $Bin ('yt-dlp' + $Exe)
New-Item -ItemType Directory -Force -Path $Bin, $Jobs | Out-Null
$env:PATH = $Bin + [IO.Path]::PathSeparator + $env:PATH
$env:PYTHONIOENCODING = 'utf-8'

function Say($msg, $color) { if (-not $color) { $color = 'Gray' }; Write-Host $msg -ForegroundColor $color }

# ---------- running hidden, and starting with Windows ----------
$PortMain = 8765
$Vbs = Join-Path $App 'hidden.vbs'
$Lnk = $null; if ($IsWin) { $Lnk = Join-Path ([Environment]::GetFolderPath('Startup')) 'PB Downloader.lnk' }
function Test-Running {
  try { $r = Invoke-WebRequest -Uri "http://localhost:$PortMain/api/ping" -Headers @{ 'X-PB' = '1' } -UseBasicParsing -TimeoutSec 2; return ($r.StatusCode -eq 200) } catch { return $false }
}
function Use-Wscript { return ($IsWin -and (Test-Path (Join-Path $env:WINDIR 'System32\wscript.exe')) -and (Test-Path $Vbs)) }
function Start-Hidden {
  $ps = Join-Path $PSHOME 'powershell.exe'; if (-not (Test-Path $ps)) { $ps = 'powershell.exe' }
  if (Use-Wscript) { Start-Process -FilePath 'wscript.exe' -ArgumentList ('"' + $Vbs + '"') }
  else { Start-Process -FilePath $ps -WindowStyle Hidden -ArgumentList ('-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "' + (Join-Path $App 'server.ps1') + '" -Background') }
}
function Add-Startup {
  if (-not $Lnk) { return }
  $sh = New-Object -ComObject WScript.Shell
  $s = $sh.CreateShortcut($Lnk)
  if (Use-Wscript) { $s.TargetPath = Join-Path $env:WINDIR 'System32\wscript.exe'; $s.Arguments = '"' + $Vbs + '"' }
  else { $s.TargetPath = Join-Path $PSHOME 'powershell.exe'; $s.Arguments = '-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "' + (Join-Path $App 'server.ps1') + '" -Background'; $s.WindowStyle = 7 }
  $s.WorkingDirectory = $App; $s.Description = 'PB Downloader, runs in the background'
  $s.Save()
}
if ($Uninstall) {
  if ($Lnk -and (Test-Path $Lnk)) { Remove-Item -LiteralPath $Lnk -Force }
  try { Invoke-WebRequest -Uri "http://localhost:$PortMain/api/quit" -Method Post -Headers @{ 'X-PB' = '1' } -UseBasicParsing -TimeoutSec 3 | Out-Null } catch {}
  Say ''
  Say '  PB Downloader is turned off and won''t start with Windows any more.' 'Green'
  Say '  Double-click Start Downloader to turn it back on.'
  Say ''
  Start-Sleep -Seconds 4
  exit 0
}
if ($Background) {
  if (Test-Running) { exit 0 }      # already running
  try { Start-Transcript -Path (Join-Path $App 'server.log') -Force | Out-Null } catch {}
}

# ---------- downloads folder ----------
function Get-DownloadsDir {
  $d = $null
  if ($IsWin) { try { $d = (New-Object -ComObject Shell.Application).NameSpace('shell:Downloads').Self.Path } catch {} }
  if (-not $d) { $d = Join-Path $HOME 'Downloads' }
  $out = Join-Path $d 'PB Downloads'
  New-Item -ItemType Directory -Force -Path $out | Out-Null
  return $out
}
$OutDir = Get-DownloadsDir

# ---------- first run: fetch the tools ----------
function Get-File($url, $dest) {
  $curl = Get-Command curl.exe -ErrorAction SilentlyContinue
  if ($curl) { & $curl.Source -L --fail --progress-bar -o $dest $url; if ($LASTEXITCODE -ne 0) { throw "Download failed: $url" } }
  else { Invoke-WebRequest -Uri $url -OutFile $dest -UseBasicParsing }
}
function Expand-Only($zip, $names, $dest) {
  $z = [IO.Compression.ZipFile]::OpenRead($zip)
  try {
    foreach ($e in $z.Entries) {
      if ($names -contains $e.Name) { [IO.Compression.ZipFileExtensions]::ExtractToFile($e, (Join-Path $dest $e.Name), $true) }
    }
  } finally { $z.Dispose() }
}
if ($IsWin) {
  if (-not (Test-Path $YtDlp)) {
    Say 'Getting yt-dlp (one time only)...' 'Green'
    Get-File 'https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp.exe' $YtDlp
  } else {
    # Instagram and TikTok change often, so keep yt-dlp up to date (runs quietly in the background)
    Start-Process -FilePath $YtDlp -ArgumentList '-U' -WindowStyle Hidden | Out-Null
  }
  if (-not (Test-Path (Join-Path $Bin 'ffmpeg.exe'))) {
    Say 'Getting ffmpeg, which joins video and sound (one time only, about 150 MB)...' 'Green'
    $zip = Join-Path $Bin 'ffmpeg.zip'
    Get-File 'https://github.com/yt-dlp/FFmpeg-Builds/releases/download/latest/ffmpeg-master-latest-win64-gpl.zip' $zip
    Expand-Only $zip @('ffmpeg.exe', 'ffprobe.exe') $Bin
    Remove-Item $zip -Force
  }
  if (-not (Test-Path (Join-Path $Bin 'deno.exe'))) {
    Say 'Getting Deno, which YouTube needs (one time only)...' 'Green'
    try {
      $zip = Join-Path $Bin 'deno.zip'
      Get-File 'https://github.com/denoland/deno/releases/latest/download/deno-x86_64-pc-windows-msvc.zip' $zip
      Expand-Only $zip @('deno.exe') $Bin
      Remove-Item $zip -Force
    } catch { Say 'Could not get Deno. Instagram and TikTok still work; YouTube may offer fewer qualities.' 'Yellow' }
  }
}
if (-not (Test-Path $YtDlp)) { $c = Get-Command yt-dlp -ErrorAction SilentlyContinue; if ($c) { $YtDlp = $c.Source } }
if ($Install) {
  try { Add-Startup } catch { Say ('Couldn''t add it to start-up: ' + $_.Exception.Message) 'Yellow' }
  # restart a copy that's already running, so an updated version takes over
  if (Test-Running) {
    try { Invoke-WebRequest -Uri "http://localhost:$PortMain/api/quit" -Method Post -Headers @{ 'X-PB' = '1' } -UseBasicParsing -TimeoutSec 3 | Out-Null } catch {}
    foreach ($i in 1..20) { Start-Sleep -Milliseconds 500; if (-not (Test-Running)) { break } }
  }
  if (-not (Test-Running)) {
    Start-Hidden
    $ok = $false; foreach ($i in 1..30) { Start-Sleep -Milliseconds 500; if (Test-Running) { $ok = $true; break } }
  } else { $ok = $true }
  Say ''
  if ($ok) {
    Say '  PB Downloader is running in the background.' 'Green'
    Say '  It starts by itself when Windows starts, so there''s no window to keep open.'
    Say '  Use the Downloader tab in the dashboard. Videos are saved to Downloads > PB Downloads.'
    Say '  This window closes by itself.'
    Start-Sleep -Seconds 5; exit 0
  } else {
    Say '  PB Downloader didn''t start. Look at app\server.log, or send it to whoever set this up.' 'Red'
    Read-Host '  Press Enter to close'; exit 1
  }
}

# ---------- jobs ----------
$JobTable = @{}
$NextId = 1
# the PB Dashboard may send links here too
$AllowedOrigins = @('https://ferozmilele-cyber.github.io')
# the last quality and sign-in picked on this page, used for links sent from the dashboard
$SettingsFile = Join-Path $App 'settings.json'
$Last = @{ quality = 'best'; cookies = '' }
if (Test-Path $SettingsFile) { try { $o = Get-Content -Raw -LiteralPath $SettingsFile | ConvertFrom-Json; if ($o.quality) { $Last.quality = [string]$o.quality }; $Last.cookies = [string]$o.cookies } catch {} }
function Save-Last { try { Set-Content -LiteralPath $SettingsFile -Value (ConvertTo-Json -InputObject $Last -Compress) -Encoding UTF8 } catch {} }
function Clean-Name([string]$n) {
  $n = ($n -replace '[<>:"/\\|?*\x00-\x1F]', ' ' -replace '\s+', ' ').Trim().TrimEnd('.')
  if ($n.Length -gt 80) { $n = $n.Substring(0, 80).Trim() }
  return ($n -replace '%', '%%')
}

function Q([string]$s) {
  # quote one command-line argument for Windows
  if ($s -eq '') { return '""' }
  if ($s -notmatch '[\s"]') { return $s }
  $s = $s -replace '(\\*)"', '$1$1\"'
  $s = $s -replace '(\\+)$', '$1$1'
  return '"' + $s + '"'
}

function Read-Shared($path) {
  if (-not (Test-Path $path)) { return '' }
  try {
    $fs = [IO.File]::Open($path, 'Open', 'Read', 'ReadWrite')
    try { $sr = New-Object IO.StreamReader($fs, [Text.Encoding]::UTF8); return $sr.ReadToEnd() } finally { $fs.Dispose() }
  } catch { return '' }
}

function Start-Job2($url, $quality, $cookies, $name) {
  # unique for every download, even after a restart, so a job never reads another video's files
  $id = (Get-Date -Format 'yyMMddHHmmss') + '-' + [string]$script:NextId; $script:NextId++
  $dir = Join-Path $Jobs $id
  if (Test-Path -LiteralPath $dir) { Remove-Item -LiteralPath $dir -Recurse -Force -ErrorAction SilentlyContinue }
  New-Item -ItemType Directory -Force -Path $dir | Out-Null
  $infoFile = Join-Path $dir 'info.json'
  $doneFile = Join-Path $dir 'done.txt'
  $fmt = switch ($quality) {
    '1080'  { 'bv*[height<=1080][vcodec^=avc1]+ba[acodec^=mp4a]/bv*[height<=1080][ext=mp4]+ba[ext=m4a]/b[height<=1080][ext=mp4]/bv*[height<=1080]+ba/b[height<=1080]/b' }
    '720'   { 'bv*[height<=720][vcodec^=avc1]+ba[acodec^=mp4a]/bv*[height<=720][ext=mp4]+ba[ext=m4a]/b[height<=720][ext=mp4]/bv*[height<=720]+ba/b[height<=720]/b' }
    'max'   { 'bv*+ba/b' }
    'audio' { 'ba/b' }
    default { 'bv*[vcodec^=avc1]+ba[acodec^=mp4a]/bv*[ext=mp4]+ba[ext=m4a]/b[ext=mp4]/bv*+ba/b' }
  }
  $tmpl = '%(uploader,channel,extractor_key)s - %(title).70B [%(id)s].%(ext)s'
  $nm = Clean-Name $name
  if ($nm) { $tmpl = $nm + ' [%(id)s].%(ext)s' }
  $a = New-Object System.Collections.Generic.List[string]
  foreach ($x in @('--newline', '--no-playlist', '--no-colors', '--no-mtime', '--windows-filenames', '--trim-filenames', '180',
                  '-f', $fmt,
                  '-o', (Join-Path $OutDir $tmpl),
                  '--progress-template', 'download:PROG|%(progress._percent_str)s|%(progress._speed_str)s|%(progress._eta_str)s',
                  '--print-to-file', 'video:%(.{title,thumbnail,duration_string,uploader,channel,extractor_key,webpage_url})j', $infoFile,
                  '--print-to-file', 'after_move:%(filepath)s', $doneFile)) { $a.Add($x) }
  if ($quality -eq 'audio') { foreach ($x in @('-x', '--audio-format', 'mp3', '--audio-quality', '0')) { $a.Add($x) } }
  elseif ($quality -eq 'max') { foreach ($x in @('--merge-output-format', 'mp4/mkv')) { $a.Add($x) } }
  else { foreach ($x in @('--merge-output-format', 'mp4')) { $a.Add($x) } }
  if (Test-Path (Join-Path $Bin ('deno' + $Exe))) { $a.Add('--js-runtimes'); $a.Add('deno:' + $Bin) }
  if ($cookies -and @('firefox', 'edge', 'chrome', 'brave') -contains $cookies) { $a.Add('--cookies-from-browser'); $a.Add($cookies) }
  $a.Add('--'); $a.Add($url)
  $argLine = ($a | ForEach-Object { Q $_ }) -join ' '
  $sp = @{ FilePath = $YtDlp; ArgumentList = $argLine; WorkingDirectory = $dir; PassThru = $true
           RedirectStandardOutput = (Join-Path $dir 'out.log'); RedirectStandardError = (Join-Path $dir 'err.log') }
  if ($IsWin) { $sp.WindowStyle = 'Hidden' }
  $p = Start-Process @sp
  $script:JobTable[$id] = @{ id = $id; url = $url; quality = $quality; cookies = $cookies; name = $name; from = $from; dir = $dir; proc = $p; started = [DateTime]::Now }
  return $id
}

function Friendly($err) {
  if ($err -match 'login|log in|logged-in|sign in|rate-limit|requested content is not available|empty media response|cookies') {
    return 'This site wants you to be signed in. Open "Signed in with", pick the browser you use for it, and try again.'
  }
  if ($err -match 'Unsupported URL') { return 'This link isn''t supported. Paste a link to a single post, reel or video.' }
  if ($err -match 'Private video|private') { return 'This video is private.' }
  if ($err -match 'could not copy|cookie database|DPAPI|decrypt') { return 'Couldn''t read that browser''s sign-in. Close the browser completely and try again, or pick Firefox.' }
  if ($err -match 'ffmpeg') { return 'ffmpeg is missing. Close this window and run Start Downloader again.' }
  if ($err -match 'Unable to download webpage|Unable to connect|timed out|getaddrinfo|Connection refused|Network is unreachable|proxy') { return 'Couldn''t reach the site. Check the internet connection and try again.' }
  if ($err -match 'HTTP Error 404|does not exist|been removed|not found') { return 'This post can''t be found. It may have been deleted.' }
  if ($err) {
    $m = ($err -replace '^ERROR:\s*', '' -replace '\[[^\]]+\]\s*[^:]*:\s*', '' -replace ';?\s*please report this issue.*$', '')
    if ($m.Length -gt 160) { $m = $m.Substring(0, 157) + '...' }
    return $m
  }
  return 'The download stopped. Try again.'
}

function Job-State($j) {
  $o = [ordered]@{ id = $j.id; url = $j.url; quality = $j.quality; label = $j.name; from = $j.from; state = 'working'; pct = 0; speed = ''; eta = ''; pass = 1; file = ''; name = ''; error = ''; info = $null }
  $info = (Read-Shared (Join-Path $j.dir 'info.json')).Trim()
  if ($info) { try { $o.info = ($info -split "`n")[0] | ConvertFrom-Json } catch {} }
  $log = Read-Shared (Join-Path $j.dir 'out.log')
  $last = $null; $pass = 1; $prev = -1
  foreach ($line in ($log -split "`n")) {
    if ($line.StartsWith('PROG|')) {
      $parts = $line.Trim().Split('|')
      $pct = 0; [double]::TryParse(($parts[1] -replace '[%\s]', ''), [Globalization.NumberStyles]::Float, [Globalization.CultureInfo]::InvariantCulture, [ref]$pct) | Out-Null
      if ($pct + 5 -lt $prev) { $pass++ }
      $prev = $pct; $last = $parts
    }
  }
  if ($last) { $o.pct = $prev; $o.speed = $last[2].Trim(); if ($last.Count -gt 3) { $o.eta = $last[3].Trim() } }
  $o.pass = $pass
  $done = (Read-Shared (Join-Path $j.dir 'done.txt')).Trim()
  if ($done) { $done = ($done -split "`n")[-1].Trim() }
  if ($j.proc.HasExited) {
    if ($done -and (Test-Path -LiteralPath $done)) { $o.state = 'done'; $o.pct = 100; $o.file = $done; $o.name = [IO.Path]::GetFileName($done) }
    elseif ($j.canceled) { $o.state = 'canceled' }
    else {
      $err = ''
      foreach ($line in ((Read-Shared (Join-Path $j.dir 'err.log')) -split "`n")) { if ($line -match '^ERROR:') { $err = $line.Trim() } }
      $o.state = 'error'; $o.error = Friendly $err
    }
  } elseif ($o.pct -ge 100 -or ($last -eq $null -and $o.info)) {
    if ($o.pct -ge 100) { $o.state = 'merging' }
  }
  if (-not $o.info -and $o.state -eq 'working' -and -not $last) { $o.state = 'starting' }
  return $o
}

# ---------- http ----------
function Origin-OK($ctx) { $o = $ctx.Request.Headers['Origin']; return ($o -and ($AllowedOrigins -contains $o)) }
function Send($ctx, $code, $body, $type) {
  if (-not $type) { $type = 'application/json; charset=utf-8' }
  if (Origin-OK $ctx) { $ctx.Response.Headers['Access-Control-Allow-Origin'] = $ctx.Request.Headers['Origin']; $ctx.Response.Headers['Vary'] = 'Origin' }
  $bytes = [Text.Encoding]::UTF8.GetBytes([string]$body)
  $ctx.Response.StatusCode = $code
  $ctx.Response.ContentType = $type
  $ctx.Response.Headers['Cache-Control'] = 'no-store'
  $ctx.Response.ContentLength64 = $bytes.Length
  $ctx.Response.OutputStream.Write($bytes, 0, $bytes.Length)
  $ctx.Response.OutputStream.Close()
}
function Json($o) { return (ConvertTo-Json -InputObject $o -Depth 6 -Compress) }
function Body($ctx) {
  $sr = New-Object IO.StreamReader($ctx.Request.InputStream, [Text.Encoding]::UTF8)
  $t = $sr.ReadToEnd(); if (-not $t) { return @{} }
  return ($t | ConvertFrom-Json)
}

$listener = $null; $Port = $PortMain
$l = New-Object Net.HttpListener
$l.Prefixes.Add("http://localhost:$Port/")
try { $l.Start(); $listener = $l } catch { try { $l.Close() } catch {} }
if (-not $listener) {
  Say "Could not start: another app is using port $Port." 'Red'
  if (-not $Background) { Read-Host 'Press Enter to close' }
  exit 1
}
$Base = "http://localhost:$Port"
Say ''
Say "  PB Downloader is running at $Base" 'Green'
Say "  Videos are saved to $OutDir"
if (-not $Background) {
  Say '  Keep this window open while you download. Close it to stop.'
  if ($IsWin -and -not $env:PB_NO_BROWSER) { Start-Process $Base }
}
Say ''
$Quit = $false

# start clean: job folders from earlier days must never be mixed up with new links
try { Get-ChildItem -LiteralPath $Jobs -Force | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue } catch {}
$Page = Join-Path $App 'index.html'
while ($listener.IsListening) {
  $task = $listener.GetContextAsync()
  while (-not $task.AsyncWaitHandle.WaitOne(250)) { }
  $ctx = $task.Result
  try {
    $path = $ctx.Request.Url.AbsolutePath
    $method = $ctx.Request.HttpMethod
    if ($path -eq '/' -or $path -eq '/index.html') { Send $ctx 200 ([IO.File]::ReadAllText($Page, [Text.Encoding]::UTF8)) 'text/html; charset=utf-8'; continue }
    if (-not $path.StartsWith('/api/')) { Send $ctx 404 '{}'; continue }
    if ($method -eq 'OPTIONS') {
      # permission check the browser does before the dashboard sends a link
      if (Origin-OK $ctx) {
        $h = $ctx.Response.Headers
        $h['Access-Control-Allow-Methods'] = 'GET, POST'; $h['Access-Control-Allow-Headers'] = 'Content-Type, X-PB'
        $h['Access-Control-Allow-Private-Network'] = 'true'; $h['Access-Control-Max-Age'] = '600'
        Send $ctx 204 ''
      } else { Send $ctx 403 '' }
      continue
    }
    # only this page may use the API (other websites can't send this header without permission)
    if ($ctx.Request.Headers['X-PB'] -ne '1') { Send $ctx 403 '{"error":"forbidden"}'; continue }
    switch ($path) {
      '/api/state' {
        $list = @($script:JobTable.Values | Sort-Object { $_.started } -Descending | ForEach-Object { Job-State $_ })
        Send $ctx 200 (Json ([ordered]@{ folder = $OutDir; ready = (Test-Path $YtDlp); jobs = $list }))
      }
      '/api/ping' { Send $ctx 200 (Json @{ ok = $true; folder = $OutDir }) }
      '/api/quit' {
        foreach ($j in @($script:JobTable.Values)) { if (-not $j.proc.HasExited) { if ($IsWin) { & taskkill.exe /PID $j.proc.Id /T /F | Out-Null } else { try { $j.proc.Kill() } catch {} } } }
        Send $ctx 200 '{}'; $script:Quit = $true
      }
      '/api/add' {
        $b = Body $ctx; $ids = @()
        $q = [string]$b.quality; $c = [string]$b.cookies
        # links from the dashboard use whatever was last picked on this page
        if ($q -eq 'auto' -or -not $q) { $q = $Last.quality } elseif (-not (Origin-OK $ctx)) { $Last.quality = $q }
        if ($c -eq 'auto') { $c = $Last.cookies } elseif (-not (Origin-OK $ctx)) { $Last.cookies = $c }
        Save-Last
        $script:from = ''; if (Origin-OK $ctx) { $script:from = 'Dashboard' }
        foreach ($u in @($b.urls)) {
          $u = ([string]$u).Trim()
          if ($u -match '^https?://[^\s"<>]+$') { $ids += (Start-Job2 $u $q $c ([string]$b.name)) }
        }
        Send $ctx 200 (Json @{ ids = $ids })
      }
      '/api/retry' {
        $b = Body $ctx; $j = $script:JobTable[[string]$b.id]
        if ($j) { $script:JobTable.Remove($j.id); $script:from = $j.from; $c = [string]$b.cookies; if ($c -eq 'auto') { $c = $Last.cookies }; $id = Start-Job2 $j.url ([string]$b.quality) $c $j.name; Send $ctx 200 (Json @{ id = $id }) } else { Send $ctx 404 '{}' }
      }
      '/api/cancel' {
        $b = Body $ctx; $j = $script:JobTable[[string]$b.id]
        if ($j) {
          if (-not $j.proc.HasExited) {
            $j.canceled = $true
            if ($IsWin) { & taskkill.exe /PID $j.proc.Id /T /F | Out-Null } else { try { $j.proc.Kill() } catch {} }
          }
          Send $ctx 200 '{}'
        } else { Send $ctx 404 '{}' }
      }
      '/api/remove' {
        $b = Body $ctx; $j = $script:JobTable[[string]$b.id]
        if ($j -and $j.proc.HasExited) { $script:JobTable.Remove($j.id); try { Remove-Item -LiteralPath $j.dir -Recurse -Force } catch {} }
        Send $ctx 200 '{}'
      }
      '/api/clear' {
        foreach ($k in @($script:JobTable.Keys)) { $j = $script:JobTable[$k]; if ($j.proc.HasExited) { $script:JobTable.Remove($k); try { Remove-Item -LiteralPath $j.dir -Recurse -Force } catch {} } }
        Send $ctx 200 '{}'
      }
      '/api/show' {
        $b = Body $ctx; $j = $script:JobTable[[string]$b.id]
        if ($j) { $s = Job-State $j; if ($s.file -and $IsWin) { Start-Process explorer.exe -ArgumentList ('/select,' + (Q $s.file)) } }
        elseif ($IsWin) { Start-Process explorer.exe -ArgumentList (Q $OutDir) }
        Send $ctx 200 '{}'
      }
      '/api/play' {
        $b = Body $ctx; $j = $script:JobTable[[string]$b.id]
        if ($j) { $s = Job-State $j; if ($s.file -and $IsWin) { Start-Process -FilePath $s.file } }
        Send $ctx 200 '{}'
      }
      default { Send $ctx 404 '{}' }
    }
  } catch {
    try { Send $ctx 500 (Json @{ error = $_.Exception.Message }) } catch {}
  }
  if ($script:Quit) { break }
}
try { $listener.Stop(); $listener.Close() } catch {}
