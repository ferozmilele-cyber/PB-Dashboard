@echo off
title PB Downloader setup
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0app\server.ps1" -Install
